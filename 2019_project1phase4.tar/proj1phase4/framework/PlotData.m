classdef PlotData < handle
    properties
        dplt
    end
end