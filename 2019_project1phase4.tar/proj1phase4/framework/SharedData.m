classdef SharedData < handle
    properties
        t_init
        state
        qd
        t
        iter
        history
    end
end