function [F, M, trpy, drpy] = controller(qd, t, qn, params)
% CONTROLLER quadrotor controller
% The current states are:
%
% qd{qn}.pos, qd{qn}.vel, qd{qn}.euler = [roll;pitch;yaw], qd{qn}.omega

% The desired states are:
% qd{qn}.pos_des, qd{qn}.vel_des, qd{qn}.acc_des, qd{qn}.yaw_des, qd{qn}.yawdot_des
% Using these current and desired states, you have to compute the desired controls
%

% =================== Your code goes here ===================


% =================== Your code ends here ===================

%
% Note: F and M are ignored, you can leave them empty.
%
% You must output a valid trpy, since F and M are ignored!
trpy = [0, 0, 0, 0]; % thrust, yaw, pitch roll

drpy = [0, 0, 0, 0]; % Leave this one at zero

end
